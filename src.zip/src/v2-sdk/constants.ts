import JSBI from 'jsbi'

export const INIT_CODE_HASH = '0x437f2bf45eed8d2cd275f01cb0896e7f5526eef54add46c4a5d9cc77f05e5c7e'

export const MINIMUM_LIQUIDITY = JSBI.BigInt(1000)

// exports for internal consumption
export const ZERO = JSBI.BigInt(0)
export const ONE = JSBI.BigInt(1)
export const FIVE = JSBI.BigInt(5)
export const _997 = JSBI.BigInt(997)
export const _1000 = JSBI.BigInt(1000)
