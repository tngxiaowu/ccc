export enum AssetActions {
  ADD_VALUE = 'ADD_VALUE',
}
