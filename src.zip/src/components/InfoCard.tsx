import React from 'react'
import styled from 'styled-components'
import { TYPE } from 'theme'
import { AutoColumn } from './Column'
import { CardBGImage, CardNoise, CardSection, DataCard } from './farm/styled'
import { RowBetween } from './Row'
import { Glow } from '../pages/AppBody'

const VoteCard = styled(DataCard)`
  overflow: hidden;
  white-space: pre-line;
  background-color: #fff;
`

export function InfoCard({
  title,
  description,
  style,
}: {
  title: string
  description: string | React.ReactNode
  style?: any
}) {
  return (
    <VoteCard style={style}>
      <CardBGImage />
      <CardSection>
        <AutoColumn gap="md">
          <RowBetween>
            <TYPE.blue fontSize={18} fontWeight={600}>
              {title}
            </TYPE.blue>
          </RowBetween>
          <RowBetween>
            <TYPE.blue fontSize={14}>{description}</TYPE.blue>
          </RowBetween>
        </AutoColumn>
      </CardSection>
      <CardBGImage />
      <CardNoise />
    </VoteCard>
  )
}
