import { UNISWAP_GRANTS_PROPOSAL_DESCRIPTION } from './uniswap_grants_proposal_description'

// Proposals are 0-indexed
export const PROPOSAL_DESCRIPTION_TEXT: { [proposalId: number]: string } = {
  [2]: UNISWAP_GRANTS_PROPOSAL_DESCRIPTION,
}
