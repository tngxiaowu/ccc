export enum ChainId {
  MAINNET = 8453,
  TESTNET = 5,
}

export const NETWORK_URLS: {
  [chainId in ChainId]: string
} = {
  [ChainId.MAINNET]: `https://mainnet.base.org`,
  [ChainId.TESTNET]: `https://goerli.infura.io/v3/2af120afa0334f62b933e543067d872d`,
}
