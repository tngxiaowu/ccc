/**
 *
 * https://github.com/diffusion-fi/v2-periphery/blob/main/scripts/config/config.ts
 *
 * When changing this also update: cypress/integration/contracts.ts
 *
 */

const PERIPHERY_TESTNET = {
  factory: '0xC324d0c6879ccccd3b06dAD4f9cC6879b749964a',
  weth9: '0xB4FBF271143F4FBf7B91A5ded31805e42b2208d6',
  router: '0x9AA957fd3d86FEcE674e8a754Ac6D7eDFe13EC8D',
  mockUSDC: '0xf56dc6695cF1f5c364eDEbC7Dc7077ac9B586068',
  multicall2: '0x5ba1e12693dc8f9c48aad8770482f4739beed696',
  miniChef: '0x183f074e63E1af6762B7236ac865249672ADb691',
  diffusion: '0xE2f09864A99D400353719F9F38FEBa93210e0d9c',
}

const MAINNET_PERIPHERY = {
  factory: '0xC324d0c6879ccccd3b06dAD4f9cC6879b749964a',
  weth9: '0xB4FBF271143F4FBf7B91A5ded31805e42b2208d6', //weth
  router: '0x9AA957fd3d86FEcE674e8a754Ac6D7eDFe13EC8D',
  multicall2: '0x5ba1e12693dc8f9c48aad8770482f4739beed696', //不晓得啥玩意
  //
  minichef: '0x183f074e63E1af6762B7236ac865249672ADb691', //stake
  diffusion: '0xE2f09864A99D400353719F9F38FEBa93210e0d9c', // token
}

const TESTNET_STABLE_PAIRS: string[] = []

const MAINNET_STABLE_PAIRS: string[] = []

export const MAINNET = {
  ...MAINNET_PERIPHERY,
  stablePairs: MAINNET_STABLE_PAIRS,
  diffusionbar: '0xfbD53f3541a304A78E947640C06D848851438e0f',  // xtoken
  airdrop: '0x07D5524C79e01e1e3c4aFbD3228ffbAB90d22a84', // 不知道啥玩意
}

export const TESTNET = {
  ...PERIPHERY_TESTNET,
  stablePairs: TESTNET_STABLE_PAIRS,
  airdrop: '0x2F7Ad6172388aED2017FBfA1631724F172360Ab1',
  diffusionbar: '0x07D5524C79e01e1e3c4aFbD3228ffbAB90d22a84', // true one is '0x3A5E791405526EFaDf1432Bac8d114B77Da3628c',
}
